/* 
 * File:   init.h
 * Author: eleves
 *
 * Created on 27 mai 2016, 14:18
 */

#ifndef INIT_H
#define	INIT_H

#ifdef	__cplusplus
extern "C" {
#endif

void init(void);


#ifdef	__cplusplus
}
#endif

#endif	/* INIT_H */

